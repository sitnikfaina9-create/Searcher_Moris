import os

check_folder = 'Check'

def read_banks_list(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        return [line.strip() for line in file]

def search_for_banks_in_files(check_folder, banks):
    found_folders = set()
    for folder_name in os.listdir(check_folder):
        full_path = os.path.join(check_folder, folder_name)
        if os.path.isdir(full_path):
            for root, dirs, files in os.walk(full_path):
                for file in files:
                    if file.endswith('.txt'):
                        file_path = os.path.join(root, file)
                        with open(file_path, 'r', encoding='utf-8') as txt_file:
                            content = txt_file.read()
                            for bank in banks:
                                if bank in content:
                                    found_folders.add(folder_name)
                                    break
                        break
    return found_folders

def write_results_to_file(folders, output_file):
    with open(output_file, 'w', encoding='utf-8') as file:
        for folder in folders:
            file.write(f"{folder}\n")

if __name__ == '__main__':
    banks_list = read_banks_list('Banks.txt')
    found_folders = search_for_banks_in_files(check_folder, banks_list)
    write_results_to_file(found_folders, 'result.txt')
    print("Поиск завершен. Результаты записаны в result.txt.")
